export const CURRENCY = "₹";
